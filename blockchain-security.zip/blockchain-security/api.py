from flask import Flask, jsonify, request, render_template, send_from_directory
from werkzeug.utils import secure_filename
from blockchain import Blockchain
from security_layer import SecurityLayer
import json
import os

# Initialize Flask app
app = Flask(_name_)

# Initialize blockchain and security layer
blockchain = Blockchain()
security = SecurityLayer()

# Configuration
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/mine', methods=['GET'])
def mine():
    last_block = blockchain.last_block
    last_proof = last_block['proof']
    proof = blockchain.proof_of_work(last_proof)
    
    blockchain.new_transaction(
        sender="0",
        recipient="miner_reward",
        data="Block Reward"
    )
    
    previous_hash = blockchain.hash(last_block)
    block = blockchain.new_block(proof, previous_hash)
    
    response = {
        'message': "New Block Forged",
        'index': block['index'],
        'transactions': block['transactions'],
        'proof': block['proof'],
        'previous_hash': block['previous_hash'],
    }
    return jsonify(response), 200

@app.route('/transactions/new', methods=['POST'])
def new_transaction():
    values = request.get_json()
    
    required = ['sender', 'recipient', 'data']
    if not all(k in values for k in required):
        return 'Missing values', 400
    
    index = blockchain.new_transaction(values['sender'], values['recipient'], values['data'])
    
    response = {'message': f'Transaction will be added to Block {index}'}
    return jsonify(response), 201

@app.route('/chain', methods=['GET'])
def full_chain():
    response = {
        'chain': blockchain.chain,
        'length': len(blockchain.chain),
    }
    return jsonify(response), 200

@app.route('/secure_file', methods=['POST'])
def secure_file():
    if 'file' not in request.files:
        return 'No file part', 400
    
    file = request.files['file']
    if file.filename == '':
        return 'No selected file', 400
    
    filename = secure_filename(file.filename)
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(filepath)
    
    try:
        transaction_data = security.secure_file(filepath)
        index = blockchain.new_transaction(
            sender="0",
            recipient="security_system",
            data=json.dumps(transaction_data)
        )
        
        response = {
            'file_path': filepath,
            'file_hash': transaction_data['file_hash'],
            'signature': transaction_data['signature'],
            'block_index': index
        }
        return jsonify(response), 200
    except Exception as e:
        return str(e), 500

@app.route('/verify_file', methods=['POST'])
def verify_file():
    if 'file' not in request.files:
        return 'No file part', 400
    
    file = request.files['file']
    stored_hash = request.form.get('stored_hash')
    signature = request.form.get('signature')
    
    if not file or not stored_hash or not signature:
        return 'Missing parameters', 400
    
    filename = secure_filename(file.filename)
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(filepath)
    
    try:
        current_hash = security.hash_file(filepath)
        is_valid = security.verify_file(filepath, stored_hash, signature)
        
        response = {
            'valid': is_valid,
            'current_hash': current_hash,
            'stored_hash': stored_hash
        }
        return jsonify(response), 200
    except Exception as e:
        return str(e), 500

if _name_ == '_main_':
    from argparse import ArgumentParser
    
    parser = ArgumentParser()
    parser.add_argument('-p', '--port', default=5000, type=int, help='port to listen on')
    args = parser.parse_args()
    port = args.port
    
    app.run(host='0.0.0.0', port=port)