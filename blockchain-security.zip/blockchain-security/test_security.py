from security_layer import SecurityLayer
import os

def test_security_system():
    # Initialize security system
    security = SecurityLayer()
    
    # Create a test file
    test_file = "test_file.txt"
    with open(test_file, "w") as f:
        f.write("This is a test file for blockchain security system.")
    
    # Secure the file
    print("\nSecuring file...")
    transaction_data = security.secure_file(test_file)
    print(f"File secured. Transaction data: {transaction_data}")
    
    # Verify file integrity (should pass)
    print("\nVerifying file integrity (original file)...")
    is_valid = security.verify_file(test_file, transaction_data['file_hash'], transaction_data['signature'])
    print(f"Verification result: {'PASS' if is_valid else 'FAIL'}")
    
    # Tamper with the file
    print("\nTampering with file...")
    with open(test_file, "a") as f:
        f.write("TAMPERED DATA")
    
    # Verify file integrity again (should fail)
    print("Verifying file integrity (tampered file)...")
    is_valid = security.verify_file(test_file, transaction_data['file_hash'], transaction_data['signature'])
    print(f"Verification result: {'PASS' if is_valid else 'FAIL'}")

if _name_ == "_main_":
    test_security_system()
