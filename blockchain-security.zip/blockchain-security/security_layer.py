from blockchain import Blockchain
import hashlib
import os

class SecurityLayer:
    def _init_(self):
        self.blockchain = Blockchain()
        self.private_key, self.public_key = self.blockchain.generate_keys()
    
    def hash_file(self, file_path):
        sha256_hash = hashlib.sha256()
        with open(file_path,"rb") as f:
            for byte_block in iter(lambda: f.read(4096),b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()
    
    def secure_file(self, file_path, recipient_public_key=None):
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File {file_path} not found")
        
        file_hash = self.hash_file(file_path)
        signature = self.blockchain.sign_data(self.private_key, file_hash)
        
        transaction_data = {
            'file_path': file_path,
            'file_hash': file_hash,
            'signature': signature.hex()
        }
        
        # In a real system, you'd encrypt this with recipient's public key
        return transaction_data
    
    def verify_file(self, file_path, stored_hash, signature_hex):
        current_hash = self.hash_file(file_path)
        if current_hash != stored_hash:
            return False
        
        signature = bytes.fromhex(signature_hex)
        return self.blockchain.verify_signature(self.public_key, signature, stored_hash)