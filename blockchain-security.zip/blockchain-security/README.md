# README.md

# Blockchain-Based Security System (Kali Linux)

This project implements a blockchain-based security system to verify file integrity and secure data using cryptographic signatures and blockchain technology.

## Prerequisites

- Kali Linux (2023.x or later)
- Python 3.x
- pip

## Setup Instructions

```bash
# 1. Clone the repo
git clone https://github.com/your-username/blockchain-security.git
cd blockchain-security

# 2. Install dependencies
sudo apt update && sudo apt upgrade -y
sudo apt install -y python3-pip git build-essential libssl-dev

# 3. Install Python libraries
pip3 install -r requirements.txt
```

## Run the API

```bash
python3 api.py --port 5000
```

Open browser: [http://localhost:5000](http://localhost:5000)

## Test File Security System

```bash
python3 test_security.py
```
# Git Commands to Upload

```bash
cd blockchain-security
git init
git add .
git commit -m "Initial commit - Blockchain Based Security System"
git branch -M main
git remote add origin https://github.com/your-username/blockchain-security.git
git push -u origin main
```

# Notes:
- All code files (`blockchain.py`, `api.py`, `security_layer.py`, `test_security.py`) must be placed at the root of the project.
- `templates/index.html` must be inside the `templates/` folder.
- `uploads/` folder is used for storing files during upload and verification — it will be created automatically at runtime.

